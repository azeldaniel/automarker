
/**
 * The Participant class models a participant in the virtual meeting system. Participants have the
 * following state attribute..
 *
 * @author Daniel Rasheed
 * @studentID 816021591
 */
 
public class Participant{
    private String participantID;
    
    public Participant(String participantId){
        participantID=participantId;
    }
    
    public static boolean verifyID(String participantID){
        String lengthValue="00000000";
        if (participantID.length()==lengthValue.length()){
                return true;
        }
        return false;
    }
    
    public String getParticipantID(){
        return participantID;
    }
    
    public String toString(){
        String participantString = "Participant: "+participantID;
        return participantString;
    }
}

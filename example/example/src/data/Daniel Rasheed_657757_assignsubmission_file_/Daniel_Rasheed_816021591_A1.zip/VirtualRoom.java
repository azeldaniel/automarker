
/**
 * The VirtualRoom class models a virtual room in the virtual meeting system. A virtual room creates and
 * manages up to a certain number of breakout rooms.
 *
 * @author Daniel Rasheed
 * @studentID 816021591
 */

public class VirtualRoom{
        private String name;
        private int breakoutRoomLimit;
        public BreakoutRoom[] breakoutRooms;
        
        public VirtualRoom(String name){
            breakoutRoomLimit=5;
        }
        
        public VirtualRoom(String name, int limit){
            breakoutRoomLimit=limit;
            BreakoutRoom[] breakoutRooms = new BreakoutRoom[breakoutRoomLimit];
        } 
        
        public int getNumberofBreakoutRooms(){
            int counter=0;
            for(int i =0; i<breakoutRoomLimit; i++){
                if(breakoutRooms[i].open){
                    counter=counter+1;
                }
            }
            return counter;
        }
       
        public void createBreakoutRooms(){
            BreakoutRoom[] breakoutRooms = new BreakoutRoom[breakoutRoomLimit];
            for (int i =0; i<breakoutRoomLimit; i++){
                breakoutRooms[i]=new BreakoutRoom(name);
            }
        }
        
        public BreakoutRoom findBreakoutRoom(int roomNumber){
            for (int i=0; i<breakoutRoomLimit; i++){
            if(breakoutRooms[i].breakoutRoomID.equals(name+roomNumber)){
                   return breakoutRooms[i];
                }
            }
            return null;
        }
        
        public boolean closeBreakoutRoom(int roomNumber){
            for (int i=0; i<breakoutRoomLimit; i++){
                if(breakoutRooms[i].breakoutRoomID.equals(name+roomNumber)){
                   breakoutRooms[i].closeBreakoutRoom();
                   return true;
                }
            }
            return false;
        }
        
        public boolean openBreakoutRoom(int roomNumber){
            int counter=0;
            for (int i=0; i<breakoutRoomLimit; i++){
                if(breakoutRooms[i].breakoutRoomID.equals(name+roomNumber)){
                   return false;
                }                
            }
            breakoutRooms[counter].openBreakoutRoom();
            return true;
        }
        
        public String listBreakoutRooms(){
            String breakoutRoomList;
            breakoutRoomList=name+" BreakoutRoom Lists: \n";
            for( int i=0; i<breakoutRoomLimit; i++){
                breakoutRoomList=breakoutRoomList + breakoutRooms[i].breakoutRoomID + "\n";
            }
            return breakoutRoomList;
        }
        
        public String listParticipantsInBreakoutRoom(int roomNumber){
            String participantList;
            for (int i=0; i<breakoutRoomLimit; i++){
                if(breakoutRooms[i].breakoutRoomID.equals(name+roomNumber)){
                   participantList=breakoutRooms[i].listParticipants();
                   return participantList;
                }
            } 
            return null;
        }
        
        public boolean addParticipantToBreakoutRoom(String participantID, int roomNumber){
            for (int i=0; i<breakoutRoomLimit; i++){
                if(breakoutRooms[i].breakoutRoomID.equals(name+roomNumber)){
                   breakoutRooms[i].addParticipant(participantID);
                   return true;
                }
            }
            return false;
        }
        
        public String findParticipantBreakoutRoom(String participantID){
            boolean flag;
            for (int i=0; i<breakoutRoomLimit; i++){
                flag=breakoutRooms[i].findParticipants(participantID);
                   if(flag){
                       return breakoutRooms[i].breakoutRoomID;
                   }
            }
            return null;
        }
    }

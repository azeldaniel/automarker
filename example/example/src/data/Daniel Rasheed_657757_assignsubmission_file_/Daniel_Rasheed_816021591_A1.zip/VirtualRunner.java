/**
 * For Testing Purposes
 * 
 *
 * @author Daniel Rasheed
 * @studentID 816021591
 */
public class VirtualRunner{
  public static void main(String args[]){
      VirtualMeetingSystem test= new VirtualMeetingSystem();
      test.loadParticipantData("participant.dat");
      test.createVirtualRoom("TestRoom");
          test.allocateParticipants("C5");
          String listsPart;
          listsPart=test.listParticipants(1);
          System.out.println(listsPart);
      }
}


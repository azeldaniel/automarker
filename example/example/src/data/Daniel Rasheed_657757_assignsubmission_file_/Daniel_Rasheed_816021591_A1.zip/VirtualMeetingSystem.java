
/**
 * The VirtualMeetingSystem class has the following methods. These are invoked
 * by the VirtualRunner class.
 *
 * @author Daniel Rasheed
 * @studentID 816021591
 */
import java.io.File;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class VirtualMeetingSystem {
    public int counter;
    public VirtualRoom virtualRoom;
    private ArrayList<String> dataToBeAllocated;
    
    public void loadParticipantData(String filename){
        counter = 0;
        try{
            File myFile = new File(filename);
            Scanner scanner= new Scanner(myFile);
            ArrayList<String> dataToBeAllocated = new ArrayList<>();
            while (scanner.hasNext()) {
                dataToBeAllocated.add(scanner.nextLine()); 
                counter++;
            }
            scanner.close();
        } catch (FileNotFoundException e){}
               
    }

    public void createVirtualRoom(String name) {
        VirtualRoom virtualRoom = new VirtualRoom(name);
        virtualRoom.createBreakoutRooms();
    }

    public void allocateParticipants(String code) {
        boolean opened;
        int roomNumber = 1;
        if (code.equals("C5")) {
            virtualRoom.openBreakoutRoom(roomNumber);
            for (int p = 0; p < counter; p++) {
                if (p%10==0) {
                    roomNumber++;
                }
                String s = String.valueOf(dataToBeAllocated.get(p));
                addParticipant(s, roomNumber);
            }
        } else if (code.equals("RR")) {
            int participant = 0;
            int room = 1;
            while (participant != counter) {
                if (room % 5==0) {
                    room = 1;
                }
                String s = String.valueOf(dataToBeAllocated.get(participant));
                addParticipant(s, roomNumber);
                room++;
                participant++;
            }
        }
    }

    public boolean addParticipant(String participantID, int roomNumber) {
        boolean added;
        added=virtualRoom.addParticipantToBreakoutRoom(participantID, roomNumber);
        return added;
    }

    public String listParticipants(int roomNumber) {
        String participantList;
        participantList = virtualRoom.listParticipantsInBreakoutRoom(roomNumber);
        return participantList;
    }

    public boolean openBreakoutRoom(int roomNumber) {
        boolean isOpen;
        isOpen = virtualRoom.openBreakoutRoom(roomNumber);
        return isOpen;
    }

    public boolean closeBreakoutRoom(int roomNumber) {
        boolean isClose;
        isClose = virtualRoom.closeBreakoutRoom(roomNumber);
        return isClose;
    }

    public String findParticipantBreakoutRoom(String participantID) {
        String Room;
        Room=virtualRoom.findParticipantBreakoutRoom(participantID);
        return Room;
    }

    public String listAllBreakoutRooms() {
        String breakoutList;
        breakoutList = virtualRoom.listBreakoutRooms();
        return breakoutList;
    }

    public String listParticipantsInAllBreakoutRooms() {
        int breakoutRoomNum = virtualRoom.getNumberofBreakoutRooms();
        String TotalList = "This is the List of ALl the Participants in all the Breakout Rooms \n";
        for (int i = 0; i < breakoutRoomNum; i++) {
            TotalList = TotalList + virtualRoom.listParticipantsInBreakoutRoom(i) + "\n";
        }
        return TotalList;
    }
}

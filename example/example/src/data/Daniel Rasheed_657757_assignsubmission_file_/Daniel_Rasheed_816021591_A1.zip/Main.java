
/**
 * Write a description of class Main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner; 
public class Main
{
   public static void main(String [] args){
       Scanner myObj = new Scanner(System.in);
       String id=myObj.nextLine();
       BreakoutRoom test =new BreakoutRoom("123");
       boolean addpart = test.addParticipant(id);
       if(addpart){
           System.out.println("Verified \n");
        }
   }
}


/**
 * The BreakoutRoom class models a breakout room in the virtual meeting system. A breakout room
 * hosts participants. It is created by a virtual room such that the breakout room’s ID is based on the
 * virtual room’s name. Participants are added to the breakout room if it is open and if there is sufficient
 * space to accommodate new participants. Duplicate participants (based on IDs) are not allowed
 *
 * @author Daniel Rasheed
 * @studentID 816021591
 */
public class BreakoutRoom{
    private String breakoutRoomID;
    private int breakoutRoomNumberCounter;
    private final int breakoutRoomSize;
    private Participant[] participants;
    private int numberOfParticipants;
    private boolean open;
    
    public BreakoutRoom(String name){
        breakoutRoomID=name+breakoutRoomNumberCounter;
        breakoutRoomSize=10;
        Participant[] pariticpants= new Participant[10];
    }
    
    public boolean addParticipant(String participantID){
        boolean flag=participants[1].verifyID(participantID);
        if(flag){
            for(int i=0; i<10; i++){
                if(participants[i].getParticipantID().equals(participantID)){
                    return false;
                }
            }
            participants[numberOfParticipants] = new Participant(participantID);
            numberOfParticipants++;
            return true;
        }
        return false;
    }
    
    public Participant findParticipant(String participantID){
        for (int i=0; i<breakoutRoomSize; i++){
            if(participants[i].getParticipantID().equals(participantID)){
                    return participants[i];
                }
        }
        return null;
    }
    
    public boolean findParticipants(String participantID){
        for (int i=0; i<breakoutRoomSize; i++){
            if(participants[i].getParticipantID().equals(participantID)){
                    return true;
                }
        }
        return false;
    }
    
    public String listParticipants(){
        String participantList;
        participantList=breakoutRoomID+" Participant Lists: \n";
        for( int i=0; i<numberOfParticipants; i++){
            participantList=participantList + participants[i].getParticipantID() + "\n";
        }
        return participantList;
    }
    
    public String toString(){
        String breakoutRoomStatus;
        if(open){
            breakoutRoomStatus=breakoutRoomID+" OPEN.";
        }
        else{
            breakoutRoomStatus=breakoutRoomID+" CLOSED.";
        }
        return breakoutRoomStatus;
    }
    
    public void closeBreakoutRoom(){
        open=false;
        participants=null;
        breakoutRoomNumberCounter=breakoutRoomNumberCounter-1;
        numberOfParticipants=0;
    }
        
    public void openBreakoutRoom(){
        open=true;
        breakoutRoomNumberCounter=breakoutRoomNumberCounter+1;
    }
}

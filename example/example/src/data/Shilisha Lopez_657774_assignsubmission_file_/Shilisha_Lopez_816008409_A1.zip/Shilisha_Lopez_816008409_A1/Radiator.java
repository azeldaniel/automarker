public class Radiator
{
    // instance variables 
    private int radiatorID = 1000;
    private boolean isTurnedOn;

    /**
     * Constructor for objects of class radiator
     */
    public Radiator()
    {
        // initialise instance variables
        radiatorID += 10;
        isTurnedOn = false;
        
    }

    public int getRadiatorID()
    {
        return radiatorID;
    }
    
    public void heats(Room rm){
        isTurnedOn = true;
    }
}



public class test
{
        public static void main(String[] args){
        Radiator r = new Radiator();
        
        System.out.println(r.getRadiatorID());
        System.out.println(r.getRadiatorID());
        
    }
}

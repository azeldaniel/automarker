
public class Room
{
    // instance variables 
    private String roomName;
    private int seatingCapacity;
    private int numRadiators;
    private Radiator[] radiators;
    /**
     * Constructor for objects of class Room
     */
    public Room(String roomName){
        // initialise instance variables
        this.roomName = roomName;
        seatingCapacity = 15;
        numRadiators = 0;
    }

    public String isHeatedBy(Radiator rd){
        if(radiators
        
        
         
    }
    

}

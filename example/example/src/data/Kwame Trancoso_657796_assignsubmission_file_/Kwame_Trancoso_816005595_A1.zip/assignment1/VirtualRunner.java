//816005595
public class VirtualRunner{
    public static void main(String[] args){
    
    VirtualMeetingSystem vs = new VirtualMeetingSystem();
    vs.loadParticipantData();
    vs.createVirtualRoom("Workshop");
    vs.vRoom.createBreakoutRooms();
    
    String s = vs.listAllBreakoutRooms();
    System.out.println(s);
    
    vs.allocateParticipants("C5");
    
    
    
    
    
    
    
    
    }
}

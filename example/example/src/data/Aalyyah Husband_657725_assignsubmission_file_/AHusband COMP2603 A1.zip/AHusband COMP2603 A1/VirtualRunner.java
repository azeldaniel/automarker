/** 
 * 
 * UNIVERSITY of the WEST INDIES
 * Aalyyah Husband 
 * 816022181 
 * COMP 2603 A1
 * 
 **/
 
public class VirtualRunner{
    // instance variables - replace the example below with your own
    //no code was required 
    // referred to W3School for additional help 
    // i watched class content such as slides and both lecture and lab 
    //recordings for assistance.
}

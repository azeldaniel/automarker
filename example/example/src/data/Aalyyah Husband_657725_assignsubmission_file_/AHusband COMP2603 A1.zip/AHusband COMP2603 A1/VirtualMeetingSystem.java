/** 
 * 
 * UNIVERSITY of the WEST INDIES
 * Aalyyah Husband 
 * 816022181 
 * COMP 2603 A1
 * 
 **/
 
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;

public class VirtualMeetingSystem{
    VirtualRoom virtualRooms;
    String [] line = new String[1000];
    int participants = 0;
    public VirtualMeetingSystem(){
    }
    
    public void loadParticipantsData(String filename){
        String s;
        try{
            File file = new File(filename);
            Scanner scan = new Scanner(file);
            while(scan.hasNextLine()){
                line[participants] = scan.nextLine();
                participants++;
            }
            scan.close();
        }
        catch(FileNotFoundException e){
            System.out.println("Error occured");
            e.printStackTrace();
        }
    
    }
    
    public void createVirtualRoom(String name){
        virtualRooms = new VirtualRoom(name);
    }
    
    public void allocateParticipants(String code){
        virtualRooms.createBreakoutRooms();
        int numberOfBreakoutRooms = virtualRooms.getNumberOfBreakoutRooms();
        int x = 0;//counter 
        int i = 0;//for the while loops 
        if (code.equals("C5")) {
            while (i < participants) {
                int roomNumber = 1;
                if (x == 5){
                    x = 0;
                    roomNumber++;
                }
                else{
                    if(x > numberOfBreakoutRooms){
                        x = 1;
                    }
                }
                virtualRooms.addParticipantToBreakoutRoom(line[i], x);
                i++; x++;
            }
        } 
        else {
            if (code.equals("RR")) {
                while (i < participants) {
                    virtualRooms.addParticipantToBreakoutRoom(line[i], x);
                    if(x == numberOfBreakoutRooms){
                        x = 1;
                    }
                    else{
                        x++;
                    }
                    i++;
                }
            }
            else 
            System.out.println("Incorrect code");
        }
    }
    
    public boolean addParticipant(String participantID, int roomNumber){
        if (virtualRooms.findBreakoutRoom(roomNumber) != null) {
            virtualRooms.addParticipantToBreakoutRoom(participantID, roomNumber);
            return true;
        }
        return false;
    }
    
    public String listParticipants(int roomNumber){
        if(virtualRooms.findBreakoutRoom(roomNumber) != null){
            return virtualRooms.listParticipantsInBreakoutRoom(roomNumber);
        }
        return null;
    }
    
    public boolean openBreakoutRoom(int roomNumber){
        if(virtualRooms.findBreakoutRoom(roomNumber) != null){
            virtualRooms.openBreakoutRoom(roomNumber);
            return true;
        }
        return false;
    }
    
    public boolean closeBreakoutRoom(int roomNumber){
        if(virtualRooms.findBreakoutRoom(roomNumber) != null){
            virtualRooms.closeBreakoutRoom(roomNumber);
            return true;
        }
        return false;
    }
    
    public String findParticipantBreakoutRoom(String participantID){
        return virtualRooms.findParticipantBreakoutRoom(participantID);
    }
    
    public String listAllBreakoutRooms(){
        String allBR;
        allBR = virtualRooms.listBreakoutRooms();
        return allBR;//virtualRooms.listBreakoutRooms();
    }
    
     public String listParticipantsInAllBreakoutRooms(){
        String info = null;
        for(int i = 0; i < virtualRooms.getNumberOfBreakoutRooms(); i++){
            info = virtualRooms.listParticipantsInBreakoutRoom(i);
        }
        return info;
    }  
}

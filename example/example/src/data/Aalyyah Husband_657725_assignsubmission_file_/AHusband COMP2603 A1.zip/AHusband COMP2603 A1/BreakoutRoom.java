/**
 * 
 *UNIVERSITY of the WEST INDIES
 *Aalyyah Husband
 *816022181
 *COMP 2603 A1
 *
 **/
public class BreakoutRoom{
    private String breakoutRoomID;
    private static int breakoutRoomNumberCounter;
    private final int breakoutRoomSize;
    private Participant[] participants; 
    private int numberOfParticipants;
    private boolean open;


    public BreakoutRoom(String name){
       breakoutRoomID = name + breakoutRoomNumberCounter;
       breakoutRoomSize = 10;
       participants = new Participant[breakoutRoomSize];
       numberOfParticipants = 0;
       open = false;
       
       breakoutRoomNumberCounter++;
    }
    
    public String getBreakoutRoomID(){
        return this.breakoutRoomID;
    }
    
    public int getNumberOfParticipants(){
        return this.numberOfParticipants;
    }
    
    public boolean getOpen(){
        if(this.numberOfParticipants < this.breakoutRoomSize){
            return this.open;
        }
        return false;
    }
     
    public boolean addParticipant(String participantID){
        //Participant p = new Participant(participantID);
        //find a way to check for validID
        if(open == true && (numberOfParticipants < breakoutRoomSize) 
        && (Participant.verifyID(participantID)==true)){
            //p.verify(participantID)==true)){ //this should work but something is wrong 
            //i believe what i did with .verify should work 
            // i had to make the function static to use the dort context 
            participants[numberOfParticipants] = new Participant(participantID);
            numberOfParticipants++;
            return true;
        }
        return false;
    }
    
    public Participant findParticipant(String participantID){
        if(open == true //{//find a way to chack for validID
            && (Participant.verifyID(participantID)==true)){//{p.verify(participantID)==true)){
                //i believe this should work 
                //i created this function as static to use static context
            for(int i = 0; i < breakoutRoomSize; i++){
                if(participantID != null && (participants[i].equals(participantID))){
                    return participants[i];
                }
            }
        }
        return null;
    }
    
    public String listParticipants(){
        String info ="Breakout Room ID: " +breakoutRoomID ;
        info += "\n";
        for(int i = 0; i < numberOfParticipants; i++){
            info += participants[i].toString();
            info += "\n";
            return info;
        }
        return info;
    }
    
    public String toString(){
        String info = breakoutRoomID;
        info += open;
        info += numberOfParticipants;
        return info;
    }
   
    public void closeBreakoutRoom(){
        if(this.open == true){
            this.open = false;
        }
    }
    
    public void openBreakoutRoom(){
        if(this.open == false){
            this.open = true; 
        }
    }
}

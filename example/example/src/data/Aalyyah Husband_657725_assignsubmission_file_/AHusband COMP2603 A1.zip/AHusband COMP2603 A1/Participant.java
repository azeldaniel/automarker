/**
* 
*UNIVERSITY of the WEST INDIES
*Aalyyah Husband
*816022181
*COMP 2603 A1
*
**/

public class Participant{
    private String participantID;

    public Participant(String participantID){
        this.participantID = participantID;
    }

    
    public static boolean verifyID(String participantID){
        int len = participantID.length();
        if(participantID!=null && len == 8){
            return true;//valid ID
        }
        return false;//UnValid ID
    }
    
    public String getParticipantID(){
        return participantID;
    }
    
    public String toString(){
        String Participant; 
        Participant = "Participant: " +participantID;
        return Participant;
    }
}

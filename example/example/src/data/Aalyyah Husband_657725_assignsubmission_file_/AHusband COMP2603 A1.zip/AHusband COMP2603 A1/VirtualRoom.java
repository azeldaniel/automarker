/**
 * 
 *UNIVERSITY of the WEST INDIES
 *Aalyyah Husband
 *816022181
 *COMP 2603 A1
 *
 **/
public class VirtualRoom{
    // instance variables - replace the example below with your own
    private String name; 
    private final int breakoutRoomLimit;
    private BreakoutRoom[] breakoutRooms;
    
    public VirtualRoom(String name){
        this.name = name;
        breakoutRoomLimit = 5;
        breakoutRooms = new BreakoutRoom[breakoutRoomLimit];
    }
    
    public VirtualRoom(String name, int limit){
        this.name = name;
        breakoutRoomLimit = limit;
        breakoutRooms = new BreakoutRoom[breakoutRoomLimit];
    }

    public int getNumberOfBreakoutRooms(){
        return this.breakoutRoomLimit;
    }
    
    public void createBreakoutRooms(){
        for(int i = 0; i < breakoutRoomLimit; i++){
            breakoutRooms [i] = new BreakoutRoom(name); 
        }
    }
    
    public BreakoutRoom findBreakoutRoom(int roomNumber){
        for(int i = 0; i < 5; i++){
            if(breakoutRooms[i].equals(roomNumber)){
                return breakoutRooms[i];
            }
        }
        return null; 
    }
    
    public boolean closeBreakoutRoom(int roomNumber){
        if(roomNumber <= breakoutRoomLimit){
            breakoutRooms[roomNumber].closeBreakoutRoom();
            return true;
        }
        else{
            return false; 
        }
    }
    
    public boolean openBreakoutRoom(int roomNumber){
         if(roomNumber <= breakoutRoomLimit){
            breakoutRooms[roomNumber].openBreakoutRoom();
            return true;
        }
        else{
            return false; 
        }
    }
    
    public String listBreakoutRooms(){
        String info ="Virtual Room: "+name;
        info += "\n";
        for(int i = 0; i < breakoutRoomLimit ; i++){
            info += breakoutRooms[i].toString();
            info +="\n";
        }
        return info;
    }
    
    public String listParticipantsInBreakoutRoom(int roomNumber){
        if (breakoutRooms[roomNumber] != null){
            return breakoutRooms[roomNumber].toString();
        }
        else{
        /*for(int i = 0; i < 5; i++){
            if(breakoutRooms[i].equals(roomNumber)){
                /*System.out.println("Virtual Room: " +this.name);
                String info = BreakoutRoom(roomNumber);
                return breakoutRooms[i].toString();
            }
        }*/
            return "Empty breakout Room";
        }
    }
    
    public boolean addParticipantToBreakoutRoom(String participantID, int roomNumber){
       BreakoutRoom b = findBreakoutRoom(roomNumber);
       if(breakoutRoomLimit <= 5 && b != null){
           b.addParticipant(participantID);
           return true;//participant added     
       }
       return false; //participant not added
    }
    
    public String findParticipantBreakoutRoom(String participantID){
        for(int i = 0; i < getNumberOfBreakoutRooms() ; i++){
            if(breakoutRooms[i].findParticipant(participantID)!=null){
                return breakoutRooms[i].getBreakoutRoomID();
            }
        }
        return "Participant not found";
    }
}


/**
 * Write a description of class VirtualMeetingSystem here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
public class VirtualMeetingSystem
{
    private String filename;
    private String Name;
    private VirtualRoom VR;
    private String IDs[];
    
    public void loadParticipantData(String filename){
      
    }
    public void createVirtualRoom(String Name){
    }    
    public void allocateParticipants(String code){
        
    }
    public boolean addParticipant(String ParticipantID, int roomNumber){
            
        return false;
    }
    public String listparticipant(int roomNumber){
        
        return " " ;
    }
    public boolean openBreakoutRoom(int roomNumber){
            
        return false;
    }
    public boolean closeBreakoutRoom(int roomNumber){
            
        return false;
    }
    public String findParticipantBreakoutRoom(String participantID){
        
        return "";
    }
    public String listAllBreakoutRooms(){
        
        return " " ;
    }
    public String listParticipantsAllBreakoutRooms(){
        
        return " " ;
    }
}

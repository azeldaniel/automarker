//ID: 816011524

public class VirtualRoom
{
    private String name;
    private int breakoutRoomLimit;
    BreakoutRoom[] breakoutRooms = new BreakoutRoom[breakoutRoomLimit];
    

    public VirtualRoom(String name)
    {
        breakoutRoomLimit = 5;
        this.name = name;
    }
    
    public VirtualRoom(String name, int limit){
        this.name = name;
        this.breakoutRoomLimit = limit;
    }
    
    public int getNumberofBreakoutRooms(){
        return breakoutRoomLimit;
    }
    
    public void createBreakoutRooms(){
        for(int i = 0; i < breakoutRoomLimit; i++){ 
            BreakoutRoom bc = new BreakoutRoom();
            breakoutRooms[i] = bc;
        }
    }
    
    public BreakoutRoom findBreakoutRoom(int roomNumber){
        for(int i = 0; i < breakoutRoomLimit; i++){
            if(breakoutRooms[i].breakoutRoomNumberCounter == roomNumber){
                return breakoutRooms[i];
            }
            else{
                return null;
            }
        }
    }
    
    public boolean closeBreakoutRoom(int roomNumber){
        
    }
    


}

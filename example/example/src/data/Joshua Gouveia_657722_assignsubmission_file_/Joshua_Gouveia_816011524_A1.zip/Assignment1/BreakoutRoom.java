//ID: 816011524

public class BreakoutRoom
{
    
    private String breakoutRoomID;
    private int breakoutRoomNumberCounter;
    private int breakoutRoomSize;
    private int numberOfParticipants;
    private boolean open;
    Participant[] participants;
    
    public BreakoutRoom(String name)
    {
        breakoutRoomID = name + 
    }

    public String getBreakoutRoomID(){
        return breakoutRoomID;
    }
    
    public int getNumberOfParticipants(){
        return numberOfParticipants;
    }
    
    public boolean getOpen(){
        return open;
    }
    
    
}

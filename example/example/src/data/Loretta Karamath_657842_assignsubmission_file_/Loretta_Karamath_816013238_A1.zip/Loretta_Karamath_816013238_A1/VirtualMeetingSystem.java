// 816013238

public class VirtualMeetingSystem {
    private String name;
    private String code;
    
    public VirtualMeetingSystem() {
        
    }

    public void createVirtualRoom(String name) {
        this.name = name;
    }
    
    public void allocateParticipants(String code) {
        this.code = code;
}
}
    

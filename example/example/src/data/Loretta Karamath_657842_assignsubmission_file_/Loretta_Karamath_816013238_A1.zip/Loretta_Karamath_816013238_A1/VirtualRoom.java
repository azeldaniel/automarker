// 816013238

public class VirtualRoom {
    String name;
    
    public VirtualRoom(String name) {
        this.name = name;
    }
}
    

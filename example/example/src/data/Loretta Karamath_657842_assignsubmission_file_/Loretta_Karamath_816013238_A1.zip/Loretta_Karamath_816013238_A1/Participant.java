// 816013238

public class Participant {
String participantID;

// constructor
public Participant(String participantID) {
    this.participantID = participantID;
}

public String getParticipantID() {
    return participantID;
}

public String toString() {
    return ("Participant: " + participantID);
}
}



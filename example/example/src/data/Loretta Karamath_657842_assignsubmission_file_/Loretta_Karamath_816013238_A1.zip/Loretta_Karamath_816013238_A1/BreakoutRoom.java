// 816013238

public class BreakoutRoom {
    String name;
    String breakoutRoomID;
    
    // constructor
    public BreakoutRoom(String name) {
      this.name = name; 
    }

}    

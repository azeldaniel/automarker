import java.util.*;
/*816020890*/
public class VirtualMeetingSystem{
    public void loadParticipantData(String filename){
        
        Scanner sc = new Scanner(filename);
        int [] arr = new int[100];
        int i=0;
        while(sc.hasNextLine()){
            arr[i++] = sc.nextInt();
        }
        
            
        
        
    }
    public void createVirtualRoom(String name){
        
        VirtualRoom[] virtualRoom = new VirtualRoom[5];
    }
    public void allocateParticipants(String code){
        
    }
}

// 816009482- Michael Joseph



public class VirtualMeetingSystem{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class VirtualMeetingSystem
     */
    public VirtualMeetingSystem(){
        // initialise instance variables
        x = 0;
    }

   
    protected void loadParticipantData(String filename){
       
    }
    
    public void createVirtualRoom(String name){
    
    }
    
    private void allocateParticipants(String code){
    
    }
    
    public boolean addParticipant(String participant, int roomNumber){
    boolean x= true;
    
    return x;
    }
    
    
}

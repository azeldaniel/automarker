// 816009482- Michael Joseph


public class BreakoutRoom extends VirtualRoom{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class BreakoutRoom
     */
    public BreakoutRoom()
    {
        // initialise instance variables
        x = 0;
    }

    
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}

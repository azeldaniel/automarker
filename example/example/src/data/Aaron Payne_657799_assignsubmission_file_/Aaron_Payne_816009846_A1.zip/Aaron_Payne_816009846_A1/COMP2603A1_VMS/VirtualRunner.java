
/**
 * Write a description of class VirtualRunner here.
 *
 * @author Aaron Payne | ID: 816009846
 * @version 05/02/2021
 */
public class VirtualRunner
{
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public static void main(String args[]){
        
        
    }
}

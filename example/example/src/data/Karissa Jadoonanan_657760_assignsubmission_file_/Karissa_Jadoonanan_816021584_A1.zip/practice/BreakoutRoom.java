//816021584
import java.io.File;  
import java.io.IOException;
import java.io.FileWriter;



public class BreakoutRoom
{
    // instance variables - replace the example below with your own
    private String name;
    private final int breakoutRoomSize = 10;
    private static int breakoutRoomNumberCounter;
    private Participant [] participants;
    private int numberOfParticipants;
    private boolean open;
    int i = 0;
    private String BreakoutRoomID;
    
    
    /**
     * Constructor for objects of class BreakoutRoom
     */
    public BreakoutRoom(String name)
    {
        // initialise instance variables
        this.name = name;
    }

    public class WriteToFile {
        public boolean addParticipant( String Participant){
    try {
      FileWriter myWriter = new FileWriter("participant.txt");
      myWriter.write("76459641");
      myWriter.close();
      System.out.println("New ParticipantID added");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    return true;
  }
    
public String listParticipants( ){
    if(participants==null){
        return"---";
    }else{
        return participants.toString();
    }
}
    
public void closeBreakoutRoom( ){
    while (breakoutRoomSize <= 10){
        participants[i]=null;

  numberOfParticipants = 0;
open = false;
}
}

public void openBreakoutRoom (){
    open = true ;
}
}
}
    



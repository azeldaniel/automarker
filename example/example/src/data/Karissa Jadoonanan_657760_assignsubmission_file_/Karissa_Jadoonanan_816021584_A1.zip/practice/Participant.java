//816021584
public class Participant
{
    // instance variables - replace the example below with your own
    private String participantID;

    /**
     * Constructor for objects of class Participant
     */
    public Participant(String participantID)
    {
        // initialise instance variables
        this.participantID=participantID;
    
    }


public static boolean verifyID(String participantID){
    int startval = 10000000;
    int endval = 99999999;
    int val = Integer.parseInt(participantID);
    if (val >= startval && val <= endval){
    return true;
} else 
    return false;
}

public String getParticipantID( ){
    return participantID;
}

public String toString (){
    return "Participant: " + participantID;
}
}



    

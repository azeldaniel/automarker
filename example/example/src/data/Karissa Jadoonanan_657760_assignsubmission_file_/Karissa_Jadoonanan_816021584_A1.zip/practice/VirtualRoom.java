//816021584
import java.util.*;
public class VirtualRoom
{
    // instance variables - replace the example below with your own
    private final int BreakoutRoomLimit;
    private BreakoutRoom[ ] breakoutRooms;
    private String name;

    /**
     * Constructor for objects of class VirtualRoom
     */
    public VirtualRoom(String name)
    {
        // initialise instance variables
        BreakoutRoomLimit = 5;
    }

public int getNumberOfBreakoutRooms( ){
    int totalRooms= 0;
    for(int i = 0;i <= BreakoutRoomLimit;i++){
        totalRooms = totalRooms +breakoutRooms[i].breakoutRoomNumberCounter;
    }
    return totalRooms;
}


public void createBreakoutRooms( ){
    ArrayList VirtualRoom = new ArrayList();
}
}


    

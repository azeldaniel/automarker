//816021584

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;
import java.util.*;
import java.io.*;

public class VirtualMeetingSystem{
         public class ReadingFiles{
             public void loadParticipantData (String){
                String [] IDs = readArray ("Participant.dat");
                for (int i=0; i<IDs.length; i=i+1){
                    System.out.println(IDs[i]);
                }
            }
        }        
        
            
public static String [] readArray (String filename){
    int ctr = 0;
    try {
        Scanner s1 = new Scanner (new File (filename));
        while(s1.hasNextLine()){
            ctr = ctr + 1;
            s1.next();
        }
        
        String [] IDs = new String [ctr];
        Scanner s2 = new Scanner (new File (filename));
        for (int i = 0; i < ctr; i = i+1){
            IDs [i] = s2.next();
        }
        return IDs;
    }
    catch (FileNotFoundException e){
    }
    return null;
}

public void createVirtualRoom (String virtualroom){
   ArrayList = new ArrayList();
   ArrayList = new ArrayList();
   ArrayList = new ArrayList();
   ArrayList = new ArrayList();
   ArrayList = new ArrayList();
}

public void allocateParticipants(String code ){
    try {
    ArrayList<String> lines = new ArrayList<>(Files.readAllLines(Paths.get(fileName)));
}
catch (IOException e) {
}
}
}



    





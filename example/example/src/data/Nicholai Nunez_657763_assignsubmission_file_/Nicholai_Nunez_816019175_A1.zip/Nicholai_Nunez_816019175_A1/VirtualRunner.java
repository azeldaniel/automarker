import java.util.Scanner; 
/**
 * 
 *
 * @author (Nicholai Nunez-816019175)
 * 
 */
public class VirtualRunner
{
    // instance variables - replace the example below with your own
   public static void main(String[] args){ 
       
       String keep1;
       int chosen;
       int keep2;
       VirtualMeetingSystem run= new VirtualMeetingSystem(); 
       
       run.loadParticipantData("");
       Scanner in = new Scanner(System.in);
       Scanner keyboard= new Scanner(System.in);
       Scanner in2= new Scanner(System.in);
       System.out.println("Please enter room name:");
       keep1= keyboard.nextLine();
       run.createVirtualRoom(keep1);
       
       System.out.println("Please enter CODE C5 or RR");
       keep1= keyboard.nextLine();
       run.allocateParticipants(keep1);
       
       System.out.println("Choose from options below 1 to 6");
       for (int x=0;x<50;x++){ 
           System.out.println("1. Add Participant");
           System.out.println("2. Show Participant that is in a room");
           System.out.println("3. Close/Open Room");
           System.out.println("4. Find a participant Location");
           System.out.println("5. Show managed Rooms");
           System.out.println("6. Show all the breakout rooms and participants");
           System.out.println("Enter 10 to Terminiate Program");
           chosen= in.nextInt();
           
       if (chosen==1){ 
           System.out.println("Add participant");
           System.out.println("Enter a 8 digit ID");
           keyboard.nextLine(); 
           String keep = keyboard.nextLine();
           System.out.println("Enter a room ID "); 
           int keep3= keyboard.nextInt(); 
           run.addParticipants(keep,keep3);
           
           
    }
    if(chosen==2){ 
        System.out.println("Participant that is in a room"); 
        System.out.println("Enter a room ID"); 
        keep2=keyboard.nextInt();
        System.out.println(run.listParticipants(keep2));
        
}
    if (chosen==3){ 
        System.out.println("Enter 1 to open a room or 2 to close"); 
        int chosen2= in2.nextInt(); 
                if(chosen2==1){ 
                        System.out.println("Open a room from 1-5");
                           keep2=keyboard.nextInt();
                           run.openBreakoutRoom(keep2);
                        }
            if(chosen2==2){ 
                    System.out.println("Close a room from 1-5"); 
                    keep2=keyboard.nextInt();
                    run.closeBreakoutRoom(keep2);
                }
            }
            if(chosen==4){ 
                System.out.println("Locate a Participant"); 
                keyboard.nextLine();
                keep1=keyboard.nextLine(); 
                System.out.println("Participant is at "+ run.findParticipantBreakoutRoom(keep1));
            }
            if (chosen==5){
                System.out.println("Breakout Manager");
                System.out.println(run.listAllBreakoutRooms());
            } 
            
            if(chosen==6){ 
                System.out.println("All participants in breakoutRoom");
                System.out.println(run.listParticipantInAllBreakoutRooms()); 
            }
             if(chosen==10){ 
                 System.out.println("Closing Program");
                 break; 
                }
                else if(chosen>6 && chosen!=10){ 
                    System.out.println("Enter a valid choice"); 
                }
            }
}
}
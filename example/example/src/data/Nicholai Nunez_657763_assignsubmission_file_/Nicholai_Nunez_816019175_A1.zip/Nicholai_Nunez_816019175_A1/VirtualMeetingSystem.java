
/**
 
 *
 * @author (Nicholai Nunez -816019175)
 
 */
import java.io.File; 
import java.util.Scanner;
import java.io.FileNotFoundException;
public class VirtualMeetingSystem
{
    // instance variables - replace the example below with your own
    int counter;
    public static VirtualRoom virtualRooms;
    String data[]=new String[50];
    
    
    
    public void loadParticipantData(String fileName){ 
        counter=0;
        fileName="participant.dat";
        try { 
            File file= new File(fileName); 
            Scanner myRead= new Scanner(file);
            while(myRead.hasNextLine()){ 
                String info= myRead.nextLine();
                data[counter]=info; 
                counter++;
                
    }
    myRead.close(); 
} 
        catch(FileNotFoundException error){ 
            System.out.println("Error");
            error.printStackTrace(); 
        } 
    }
    public void createVirtualRoom(String name){ 
        virtualRooms= new VirtualRoom(name); 
        virtualRooms.createBreakoutRooms(); 
        
}

        public void allocateParticipants (String code) { 
            int misc=0;
            if(code.equals("C5")){ 
                System.out.println("Option C5");
                for(int x=0;x<5;x++){ 
                    virtualRooms.openBreakoutRoom(x+1);
                    for (int j=0;j<5;j++){ 
                        addParticipants(data[x],x+1);
                            x++; 
                } 
            }
        }
        else{ 
            System.out.println("Invalid");
        }
    }
    
    public boolean addParticipants(String participantID, int roomNumber){ 
        
        return virtualRooms.addparticipantToBreakoutRoom(participantID,roomNumber);
        
    
}
     public String listParticipants(int roomNumber){ 
         String ext;
         ext=virtualRooms.listParticipantsInBreakoutRoom(roomNumber); 
         return ext; 
         

}

       public boolean openBreakoutRoom(int roomNumber) { 
           if(virtualRooms.findBreakoutRoom(roomNumber)!=null){ 
               virtualRooms.breakoutRooms[roomNumber].openBreakoutRoom();
               return true;
            }
            return false;
               
}
        public boolean closeBreakoutRoom(int roomNumber){ 
            if(virtualRooms.breakoutRooms[roomNumber]!=null){
                 
                    virtualRooms.breakoutRooms[roomNumber-1].closeBreakoutRoom();
                    return true;
        }
        return false;
        
    }
    

        public String findParticipantBreakoutRoom(String participantID){ 
            String ext;
            ext= virtualRooms.findParticipantBreakoutRoom(participantID); 
            return ext; 
    }
        public String listParticipantInAllBreakoutRooms(){ 
            System.out.println("Rooms and Participants "); 
            for(int x=0;x<5;x++){
                if(virtualRooms.getbreakoutRooms()[x].getOpen()==true){ 
                    System.out.println(listParticipants(x+1));
                }
                else if(virtualRooms.getbreakoutRooms()[x].getOpen()==false){ 
                    System.out.println(virtualRooms.getbreakoutRooms()[x].getBreakoutRoomID());
                    System.out.println("____________");
                }
}
        return ("");
    }
    public String listAllBreakoutRooms(){ 
        System.out.println("Rooms");
        for(int x=0;x<5;x++){ 
            if(virtualRooms.getbreakoutRooms()[x].getOpen()==true){ 
                System.out.println(virtualRooms.getbreakoutRooms()[x].getBreakoutRoomID());
    
}
           }
           return ("");
        }
    }


    


/**
 * 
 *
 * @author (Nicholai Nunez-816019175)
 * 
 */
public class BreakoutRoom
{
    // instance variables - replace the example below with your own
  
    private String breakoutRoomID; 
    private static int breakoutRoomNumberCounter;
    private final int  breakoutRoomSize; 
    private Participant participants[]= new Participant[10];
    private int numberOfParticipants; 
    private boolean open; 
    
    
    /**
     * Constructor for objects of class BreakoutRoom
     */
    public BreakoutRoom(String name)
    {
        // initialise instance variables
        breakoutRoomNumberCounter=0;
        breakoutRoomSize=10;
        participants= new Participant[breakoutRoomSize];
        numberOfParticipants=0;
        open= true;
        
        
    }
    

 
    public int getNumberOfParticipants()
    {
        // put your code here
        return numberOfParticipants; 
        
    }
    
    public String getBreakoutRoomID(){ 
        return breakoutRoomID;
    } 
    public boolean getOpen(){ 
        return open; 
    } 
    public void setBreakoutID(String name){
        breakoutRoomID=name; 
        
        
    }
    
    public boolean addParticipant(String participantID)
    { 
        boolean x=true; 
        int counter= participantID.length(); 
        if(open==false || numberOfParticipants==breakoutRoomSize) { 
            System.out.println("Room is closed");
            return false; 
          
    }
    if(x==true){ 
        for(int y=0; y<10;y++){ 
            if(participants[y].getParticipantID().equals("")){ 
                participants[y]= new Participant(participantID);
                y=10; 
                
}
}
numberOfParticipants=numberOfParticipants+1; 
return true; 
} 
return false; 
}

    public Participant findParticipant(String participantID) { 
        int counter=participantID.length(); 
        
        if(counter<8){ 
            System.out.println("The ID is less than 8 numbers");
            return null; 
           
        }
    for (int x = 0; x<10;x++){ 
        if (participants[x].getParticipantID().equals(participantID)){ 
            System.out.println("The participant has been found"); 
            return participants[x];
            
        }           
}
        return null; 
    }
    
    
    
      public String listParticipants(){ 
          String list=""; 
          for(int x=0; x < 10; x++){ 
              if (participants[x].getParticipantID()!=null) { 
                  list=(list+"\n"+participants[x].getParticipantID());
          
               }
            } 
        return (getBreakoutRoomID()+"\n" + list); 
    }
    
    
    public String toString (){
        String status; 
        if(open){ 
            status="OPEN";
        }else{ 
            status="CLOSED";
        } 
        return (getBreakoutRoomID()+" "+status+" "+numberOfParticipants);
        
        
        
        
        
    }
    
    
    
    
    
    
    public void closeBreakoutRoom(){ 
        for (int x=0; x<10;x++){ 
            participants[x]=null; 
            open=false; 
            numberOfParticipants=0;
            
        }
    } 
        public void openBreakoutRoom(){ 
            for (int x=0; x<10;x++){ 
                participants[x]= new Participant(""); 
                
            }
        for( int x=0; x<10;x++){ 
            open= true; 
        } 
    }
}
 


/**
 * 
 *
 * @author (Nicholai Nunez-816019175)
 * 
 */
public class VirtualRoom
{
    // instance variables - replace the example below with your own
    private String name; 
    private final int breakoutRoomLimit; 
    private BreakoutRoom[] breakoutRooms;
    
    public void setName(String name){ 
        this.name=name;
    } 
    
    public String getName(){ 
        return name; 
    } 
    
    public BreakoutRoom[] getbreakoutRooms (){ 
        return breakoutRooms;
    } 
    
    VirtualRoom(String name){
        breakoutRoomLimit=10;
        this.name=name; 
    }
    
    VirtualRoom(String name, int limit){ 
        breakoutRoomLimit=limit;
        this.name=name;
    }
    
    public int getNumberOfBreakoutRooms(){ 
            int counter=0;
            for(int x=0; x<5;x++){ 
                if(breakoutRooms[x].getOpen()==true){ 
                    counter++;
                }
            }
            return counter;
            
}

 public void createBreakoutRooms(){ 
   for (int x=0; x<breakoutRoomLimit; x++)
   {
       breakoutRooms[x]= new BreakoutRoom(name);
       System.out.println("Breakout Room: " + breakoutRooms[x].breakoutRoomID+"created");
       
}
}


public  BreakoutRoom findBreakoutRoom(int roomNumber){ 
    String full=(name+roomNumber);
    for (int x=0; x<5;x++){ 
        if(breakoutRooms[x].getBreakoutRoomID().equals(full)){ 
            return breakoutRooms[x];
}
}
 return null; 
 
}

public boolean openBreakoutRoom(int roomNumber) { 
    String full=(name+roomNumber); 
    for (int x=0;x<5;x++){ 
        if(breakoutRooms[x].getBreakoutRoomID().equals(full)){ 
            breakoutRooms[x].openBreakoutRoom(); 
            return true; 
            
}
}
        System.out.println("Invalid, Room doesn't exist");
        return false; 
        
}
       public String listParticipantsInBreakoutRoom(int roomNumber){ 
           String full=(name+roomNumber); 
           for(int x=0;x<5;x++){ 
               if(breakoutRooms[x].getBreakoutRoomID().equals(full)&& breakoutRooms[x].getOpen()==true){ 
                   return breakoutRooms[x].listParticipants();
}
    }
    return null;
}       

   public String findParticipantBreakoutRoom(String participantID){ 
           int length= participantID.length(); 
           if(length!=8)
            return null;
            
            for(int x=0;x<breakoutRoomLimit;x++){ 
                if(findBreakoutRoom(x+1)!=null){ 
                        BreakoutRoom temp= findBreakoutRoom(x+1);
                        for(int y=0;y<temp.numberOfParticipants;y++){ 
                            if(temp.participants[y].participantID.equals(participantID)){ 
                                return breakoutRooms[x].breakoutRoomID;}}}}
                                return null;
}
        public boolean addparticipantToBreakoutRoom(String participantID, int roomNumber){ 
           if(findBreakoutRoom(roomNumber)!=null){ 
               findBreakoutRoom(roomNumber).addParticipant(participantID);
               return true;
}
    return false; 
}
}


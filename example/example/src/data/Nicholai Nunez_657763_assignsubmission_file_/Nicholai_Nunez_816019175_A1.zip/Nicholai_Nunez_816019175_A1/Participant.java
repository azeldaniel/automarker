
/**
 * 
 *
 * @author (Nicholai Nunez-816019175)
 * 
 */
public class Participant 
{
    // instance variables - replace the example below with your own
    
    private String participantID;
    /**
     * Constructor for objects of class Participant
     */
     Participant(String participantID)
    {
        // initialise instance variables
        
        this.participantID=participantID; 
    }

    
   
    public  static boolean verifyID(String participantID)
    { 
        if (participantID.length() < 8 && (!participantID.equals(0))){
        return true; 
    }
    else
    return false;
    }
    
    public String getParticipantID() 
    {
        
        return participantID; 
        
    }
    
    public String toString()
    { 
         
        
        return "Participant:" + participantID; 
        
    }
        
}


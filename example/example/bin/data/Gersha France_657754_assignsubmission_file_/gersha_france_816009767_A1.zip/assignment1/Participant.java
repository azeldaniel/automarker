//816009767
public class Participant{
    private String participantID;

  
     
    public Participant(String participantID){
        
    }
    
    public boolean verifyID(String participantID){
        
        
        return true;
        
            }
    
    public String getParticipantID(){
       
        return participantID ;
    }
    
    public String toString(){
          String details =  "ParticipantID ";
         details += participantID;
       return details;
        }
    
    
    
    
    
    
    
    
    
}

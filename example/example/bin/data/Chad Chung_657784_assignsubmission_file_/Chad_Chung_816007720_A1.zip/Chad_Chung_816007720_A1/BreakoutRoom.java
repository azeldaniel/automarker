//816007720

public class BreakoutRoom{
    
    private String breakoutRoomID;
    private int breakoutRoomNumberCounter;
    private int breakoutRoomSize;
    private Participant[] participants;
    private int numberOfParticipants;
    private boolean open;








public String toString(){
String details="Breakout Room ID: "+breakoutRoomID;
details+="Breakout Room Number Counter: "+breakoutRoomNumberCounter;
details+="Breakout Room Size: "+breakoutRoomSize;
details+="Participants: "+participants;
details+="Number of Participants: "+numberOfParticipants;
details+="Open: "+open;
return details;
}

public void closeBreakoutRoom(){
    open=false;
}


public void openBreakoutRoom(){
open=true;
    }
}


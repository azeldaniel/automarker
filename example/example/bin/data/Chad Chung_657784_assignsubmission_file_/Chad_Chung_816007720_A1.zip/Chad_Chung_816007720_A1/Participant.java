//816007720

import javax.swing.Box;


public class Participant
{

    
    private String participantID;
 

public boolean verifyID(String participantID){
int numDigits=0;
while( numDigits!=0){
numDigits++;
}
if(numDigits==8){
return true;
}
return false;
}


}



















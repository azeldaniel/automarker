//816007720

import java.util.Scanner;

 public class VirtualRoom{
     
     private int breakoutRoomLimit=5;
     private String name;
     private BreakoutRoom[] breakoutRooms;


public VirtualRoom(String Name, int limit)
{
String Roomname = name;
Scanner keyboard = new Scanner(System.in);
System.out.println("Enter the limit");
limit = keyboard.nextLine();
limit=breakoutRoomLimit;
}

public int getNumberOfBreakoutRooms(){
    System.out.println("Number of breakout rooms: " + BreakoutRoom.length);
}

public static void createBreakoutRooms(){
 
    if ((getNumberOfBreakoutRooms()) == limit){
        System.out.println("The maximum capacity of breakout rooms has been reached.");
}
else{
    breakoutRooms=breakoutRooms+1;
}
}

public BreakoutRoom findBreakoutRoom(int roomNumber){
    Scanner sc = new Scanner(System.in);
    
    int n = getNumberOfBreakoutRooms();
    
    System.out.println("Please enter the room number that you are searching for.");
    int search = sc.nextInt();
    
     for(i=0;i<n;i++)
     {
         if(breakoutRooms[i]==search)
         {
             System.out.println("The room was found in Breakout Room number  "+i);
             flag=1;
             break;
         }
     }
     if(flag==0)
     {
         return null;
     }
}

public bool closeBreakoutRoom(){
    System.out.println("What is the number of the room that you wish to close?");
    Scanner keyboard = new Scanner(System.in);
    int roomToBeClosed = keyboard.nextLine() - 1;
    roomToBeClosed=this.breakoutRooms;
    
}

public bool openBreakoutRoom(){
    System.out.println("What is the number of the room that you wish to open?");
    
    int roomToBeOpened = keyboard.nextLine()-1;
    roomToBeOpened=this.breakoutRooms;
}

public String listBreakoutRooms(){
    for(int i=0; i<6; i++){
        System.out.println(breakoutRooms[i]);
}
}

public String listParticipantsInBreakoutRoom(int roomNumber){
    Scanner keyboard = new Scanner(System.in);
    roomNumber=keyboard.nextLine();
    if (roomNumber>0 && roomNumber<6)
    
    {
        System.out.println(breakoutRooms[roomNumber]);
}

else return null;

}
public boolean addParticipantToBreakoutRoom(String participantID, int roomNumber){
    if(roomNumber>0 && roomNumber<6){
        
        breakoutRooms[roomNumber]=breakoutRooms[roomNumber]+participantID;
}
}

public String findParticipantBreakoutRoom(String participantID){
Scanner keyboard = new Scanner(System.in);
participantID=keyboard.nextLine();
for(int i=0;i<6;i++){
if(participantID=breakoutRooms[i]){
    
    int roomNo=i+1;
    
System.out.println("This participant is being hosted in room "+roomNo);

    }
    
}

}
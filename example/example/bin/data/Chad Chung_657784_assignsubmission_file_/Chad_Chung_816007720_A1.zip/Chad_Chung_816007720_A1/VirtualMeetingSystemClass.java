//816007720

import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files

public class VirtualMeetingSystemClass{


  public static void main(String[] args) {
    try {
      File myObj = new File("participant.dat");
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        String data = myReader.nextLine();
        System.out.println(data);
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }



public static void createVirtualRoom(string name)
{
    BreakoutRooms[] breakoutRooms;
BreakoutRoom breakoutRooms=new BreakoutRoom();
}


public static void allocateParticipants(String code){
if(code=="C5"){
    
int j=0;
    
    for(int i=0;i<75;i++){
    Participant[i]=BreakoutRoom[j];
    int counter;
    counter++;
    
    while(counter%5=0){
        j++;
}
}
}
}

public boolean addParticipant(String participantID, int RoomNumber){
if(RoomNumber==VirtualRoom.breakoutRooms[i]){
numberofParticipants=numberofParticipants+1;
return true;
}
return false;
}

}




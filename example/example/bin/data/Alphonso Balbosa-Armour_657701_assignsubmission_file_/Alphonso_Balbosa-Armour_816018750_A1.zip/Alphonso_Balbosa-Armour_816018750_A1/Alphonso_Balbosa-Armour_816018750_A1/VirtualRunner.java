//STUDENT I.D. == 816018750
/**
 * Write a description of class VirtualRunner here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VirtualRunner
{
    // instance variables - replace the example below with your own
    public static void main(String[] args)
    {
      /* Participant
      boolean test = Participant.verifyID("84538887");
      if(test == true){
          System.out.println("true");
      }
      if(test == false){
          System.out.println("false");
      }
        
      Participant vms = new Participant("84538887");
      System.out.println(vms.toString());
      */
       
      /* BreakoutRoom
      BreakoutRoom vms = new BreakoutRoom("help");
      vms.addParticipant("84538887");
      System.out.println(vms.listParticipants());
      System.out.println(vms.toString());
      vms.closeBreakoutRoom();
      System.out.println(vms.toString());
      vms.openBreakoutRoom();
      vms.addParticipant("94538887");
      System.out.println(vms.toString());
      System.out.println(vms.listParticipants());
      */
      
      /* VirtualRoom
      VirtualRoom vms= new VirtualRoom("help");
      vms.createBreakoutRooms();
      System.out.println(vms.listBreakoutRooms());
      */
      
      /* VirtualMeetingSystem
      VirtualMeetingSystem vms = new VirtualMeetingSystem();
      vms.loadParticipantData("participant.dat");
      vms.createVirtualRoom("Workshop");
      System.out.println(vms.listAllBreakoutRooms());
      vms.allocateParticipants("C5");
      System.out.println(vms.listParticipantsInAllBreakoutRooms());
      vms.closeBreakoutRoom(5);
      System.out.println(vms.listAllBreakoutRooms());
      System.out.println(vms.listParticipantsInAllBreakoutRooms());
      vms.openBreakoutRoom(5);
      System.out.println(vms.listParticipantsInAllBreakoutRooms());
      */
    }

    
}

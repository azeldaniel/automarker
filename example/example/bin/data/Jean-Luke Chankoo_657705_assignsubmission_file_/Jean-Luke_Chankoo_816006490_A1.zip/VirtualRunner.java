//816006490
public class VirtualRunner
{

public static void main(String[] args){

VirtualMeetingSystem v= new VirtualMeetingSystem();
v.loadParticipantData("participant.dat");  

}
}

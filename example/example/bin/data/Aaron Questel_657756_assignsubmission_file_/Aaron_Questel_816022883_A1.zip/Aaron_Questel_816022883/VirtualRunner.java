package Aaron_Questel_816022883;


public class VirtualRunner
{
    public static void main(String[] args){ 
        //CREATE VIRTUAL ROOM 
        VirtualMeetingSystem vms = new VirtualMeetingSystem();
        vms.createVirtualRoom("VirtualRoom");
        System.out.println("Virtual Room Created");
        
        //LOAD DATA
        vms.loadParticipantData("participant.dat");
        System.out.println("Data loaded");
        
        //ALLOCATE PARTICIPANTS
        vms.allocateParticipants("RR");
        System.out.println("Participants allocated in Round Robin fashion");
        
        //TRY TO ADD PARTICIPANT TO FULL ROOMS
        System.out.println("Trying to add participant to full room: ");
        boolean added = vms.addParticipant("81602288",5);
        
        //CLOSE ROOM 5
        boolean closed = vms.closeBreakoutRoom(5);
        if(closed)
            System.out.println("Breakout Room 5 closed");
        else
            System.out.println("Breakout Room 5 NOT closed");
        
        //TRY TO ADD PARTICIPANT TO CLOSED ROOM
        System.out.println("Trying to add participant to closed room: ");
        added = vms.addParticipant("81602288",5);
        
        //LIST ALL OPEN BREAKOUT ROOMS
        System.out.println("List of all open breakout rooms: ");
        System.out.println(vms.listAllBreakoutRooms());
        
        //OPEN ROOM
        boolean opened = vms.openBreakoutRoom(5);
        if(opened)
            System.out.println("Breakout Room 5 opened");
        else
            System.out.println("Breakout Room 5 NOT opened");      
        
        //ADD PARTICIPANT TO OPEN ROOM
        added = vms.addParticipant("81602288",5);
            
        //LIST PARTICIPANTS IN NOW OPEN BREAKOUT ROOM
        System.out.println("Showing participant added to now open breakout room 5: ");
        System.out.println(vms.listParticipants(5));
        
        //FIND PARTICIPANT IN A BREAKOUT ROOM
        System.out.println("Finding participant number 83247855's breakout room: ");
        System.out.println(vms.findParticipantBreakoutRoom("83247855"));
        
        //LIST ALL PARTICIPANTS IN ALL ROOMS
        System.out.println("Showing all participants in all rooms: ");
        System.out.println(vms.listParticipantsInAllBreakoutRooms());
        
        
    }
}

package Aaron_Questel_816022883;


public class BreakoutRoom
{
    private String breakoutRoomID;
    private static int breakoutRoomNumberCounter = 1;    
    private final int breakoutRoomSize;
    private Participant[] participants;    
    private int numberOfParticipants;
    private boolean open;
    
    public BreakoutRoom(String name) {
        breakoutRoomID = name + "_" + breakoutRoomNumberCounter;
        breakoutRoomNumberCounter += 1;
        breakoutRoomSize = 10;
        participants = new Participant[breakoutRoomSize];
        numberOfParticipants = 0;
        open = true;
    }
    
    public boolean addParticipant(String participantID) {
        Participant p = new Participant(participantID);
        if(p.verifyID(participantID) && numberOfParticipants <= breakoutRoomSize-1 && open){     //assuming you can only add to open room
            participants[numberOfParticipants] = p;
            numberOfParticipants += 1;
            return true;
        }
        return false;
    }
    
    public Participant findParticipant(String participantID) {
        for(int i = 0; i < numberOfParticipants; i++){
            if(participantID.equals(participants[i].getParticipantID()))
                return participants[i];
        }   
        return null;
    }
    
    public String listParticipants(){
        if(!open)
            return breakoutRoomID + " is closed";
            
        String allParticipants = breakoutRoomID + "\n";
        for(int i = 0; i < numberOfParticipants; i++){
            allParticipants += participants[i].toString() + "\n";
        }
        
        return allParticipants;
    }
    
    public String toString(){
        if(open == true)
            return breakoutRoomID + " OPEN " + numberOfParticipants;
        else
            return breakoutRoomID + " CLOSED ";
    }
    
    public void closeBreakoutRoom(){
        open = false;
        for(int i = 0; i < numberOfParticipants; i++)
            participants[i] = null;
        numberOfParticipants = 0;
        breakoutRoomNumberCounter -= 1;
    }
    
    public void openBreakoutRoom(){
        open = true;
        breakoutRoomNumberCounter += 1;
    }
    
    public String getBreakoutRoomID(){
        return breakoutRoomID;
    }
    
    public int getNumberOfParticipants(){
        return numberOfParticipants;
    }
    
    public boolean getOpen(){
        return open;
    }
}

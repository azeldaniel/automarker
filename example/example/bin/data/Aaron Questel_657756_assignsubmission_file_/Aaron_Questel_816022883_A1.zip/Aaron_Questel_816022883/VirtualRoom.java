package Aaron_Questel_816022883;

    
    public class VirtualRoom
    {
        private String name;
        private final int breakoutRoomLimit;
        private BreakoutRoom[] breakoutRooms;
        private int numberOfBreakoutRooms;
        
        public VirtualRoom(String name){
            this.name = name;
            breakoutRoomLimit = 5;
            breakoutRooms = new BreakoutRoom[breakoutRoomLimit];
            numberOfBreakoutRooms = 0;
        }
        
        public VirtualRoom(String name, int limit){
            this.name = name;
            breakoutRoomLimit = limit;
            breakoutRooms = new BreakoutRoom[breakoutRoomLimit];
            numberOfBreakoutRooms = 0;
        }
    
        public int getNumberOfBreakoutRooms(){
            return breakoutRoomLimit;
        }
        
        public void createBreakoutRooms(){
            for(int i = 0; i < breakoutRoomLimit; i++){
                BreakoutRoom b = new BreakoutRoom(name);
                breakoutRooms[i] = b;
                numberOfBreakoutRooms += 1;
            }
        }
        
        public BreakoutRoom findBreakoutRoom(int roomNumber){
            if(roomNumber >= 1 && roomNumber <= breakoutRoomLimit)     //if breakoutRoom exists
                return breakoutRooms[roomNumber - 1];
            else
                return null;
        }
        
        public boolean closeBreakoutRoom(int roomNumber){
            if(roomNumber >= 1 && roomNumber <= breakoutRoomLimit) {    //if breakoutRoom exists
                breakoutRooms[roomNumber - 1].closeBreakoutRoom();
                numberOfBreakoutRooms -= 1;        
                return true;
            }
            return false;            
        }
        
        public boolean openBreakoutRoom(int roomNumber){
            if(roomNumber >= 1 && roomNumber <= breakoutRoomLimit){     //if breakoutRoom exists
                breakoutRooms[roomNumber - 1].openBreakoutRoom();
                numberOfBreakoutRooms += 1;
                return true;
            }
            return false; 
        }  
    
        public String listBreakoutRooms(){
            String list = "Virtual Room Name: " + name + "\n"; 
            for(int i = 0; i < breakoutRoomLimit; i++){              //assuming breakoutRoom not managed if it's closed
                if(breakoutRooms[i].getOpen())
                    list += breakoutRooms[i].getBreakoutRoomID() + "\n";
            }
            return list;            
        }
        
        public String listParticipantsInBreakoutRoom(int roomNumber){
            if(roomNumber >= 1 && roomNumber <= breakoutRoomLimit) {    //if breakoutRoom exists
                return breakoutRooms[roomNumber - 1].listParticipants();
            }
            return null;
        }
        
        public boolean addParticipantToBreakoutRoom(String participantID, int roomNumber){
           if(roomNumber >= 1 && roomNumber <= breakoutRoomLimit) {    //if breakoutRoom exists
               boolean added = breakoutRooms[roomNumber-1].addParticipant(participantID);
               if(added)
                   return true;
            }
           System.out.println("Participant not added");
           return false;
        }
        
        public String findParticipantBreakoutRoom(String participantID){
            for(int i = 0; i < breakoutRoomLimit; i++){
                if(breakoutRooms[i].findParticipant(participantID) != null)
                    return breakoutRooms[i].getBreakoutRoomID();
            }
            return null;
        }
        
        public String getVirtualRoomName(){
            return name;
        }
}

package Aaron_Questel_816022883;

//Aaron_Questel_816022883;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class VirtualMeetingSystem
{
    private VirtualRoom virtualRoom;
    private String data;
   
    public void loadParticipantData(String name) {
       try{
           data = "";
           File myObj = new File(name);
           Scanner myReader = new Scanner(myObj);
           while(myReader.hasNextLine()){
               data += myReader.nextLine() + " ";
           }
           myReader.close();
        }
        catch(FileNotFoundException e){
           System.out.println("An error has occurred.");
           e.printStackTrace();
        }
    }
    
    public void createVirtualRoom(String name) {
        virtualRoom = new VirtualRoom(name, 5);   
        virtualRoom.createBreakoutRooms();
    }
    
    public void allocateParticipants(String code) {
        String[] IDs = data.split(" ");
        int count = 0;
        int roomNumber;
        if(code.equals("C5")){            
            for(roomNumber = 1; roomNumber <= 5; roomNumber++){
                while(count < IDs.length){
                    boolean added = virtualRoom.addParticipantToBreakoutRoom(IDs[count], roomNumber);  
                    count += 1;
                    if(count % 10 == 0 || !added){
                        break;                    
                    }
                }
            }
        }
        
        else if(code.equals("RR")){
           for(int i = 0; i < IDs.length; i += 5){
               for(roomNumber = 1; roomNumber <= 5; roomNumber++){
                   boolean added = virtualRoom.addParticipantToBreakoutRoom(IDs[count], roomNumber);  
                   count += 1;
                }
            }
            
        }
    }
    
    public boolean addParticipant(String participantID, int roomNumber){
        boolean added = virtualRoom.addParticipantToBreakoutRoom(participantID, roomNumber);
        return added;
    }
    
    public String listParticipants(int roomNumber){
        String participants = null;
        participants = virtualRoom.listParticipantsInBreakoutRoom(roomNumber);
        return participants;
    }
    
    public boolean openBreakoutRoom(int roomNumber){
        boolean opened = virtualRoom.openBreakoutRoom(roomNumber);
        if(opened)
            return true;
        return false;
    }
    
    public boolean closeBreakoutRoom(int roomNumber){
        boolean closed = virtualRoom.closeBreakoutRoom(roomNumber);
        if(closed)
            return true;
        return false;        
    }
    
    public String findParticipantBreakoutRoom(String participantID){
        String breakoutRoomID = virtualRoom.findParticipantBreakoutRoom(participantID);
        return breakoutRoomID;
    }
    
    public String listAllBreakoutRooms(){
       String list = virtualRoom.listBreakoutRooms();
       return list;       
    }
    
    public String listParticipantsInAllBreakoutRooms(){
        String participants = "";
        for(int i = 1; i <= 5; i++){
            participants += virtualRoom.listParticipantsInBreakoutRoom(i) + "\n";
        }
        return participants;
    }
}

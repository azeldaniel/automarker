//ID: 816018588
//NAME: CHRISTINE RAMDHANIE
//COMP 2603 - ASSIGNMENT 1 

public class VirtualRunner extends VirtualMeetingSystem{ 
  

    public VirtualRunner(){

    }
    
    public static void main (String[] args){
        
    }
    
    

}

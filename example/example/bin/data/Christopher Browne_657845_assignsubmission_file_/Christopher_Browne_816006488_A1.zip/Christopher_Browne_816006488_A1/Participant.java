/*
   ID: 816006488 
   */
import java.io.*; 
import java.util.*;
import java.lang.*;

public class Participant
{
    private String participantID;
    
    public Participant(String participantID)
    {
        this.participantID=participantID;
    }

    public static boolean verifyID(String participantID){        
        int Length= participantID.length();
        if(Length == 8){
            try {
           int x= Integer.parseInt(participantID);
            } catch (NumberFormatException nfe) {
            return false;
          }
          return true;
        }
        return false;
    }
    
    public String getParticipantID(){
        return this.participantID; 
    }
    
    public String toString(){
        return ("ParticipantID: " + this.participantID);
    }
}
/*
    References:
    1.Java Read Files. Accessed February 7, 2021. https://www.w3schools.com/java/java_files_read.asp. 
    2.“Different Ways of Reading a Text File in Java.” 2018. GeeksforGeeks. September 6, 2018. https://www.geeksforgeeks.org/different-ways-reading-text-file-java/. 
    3.“How to Convert an Array to String in Java?” 2019. GeeksforGeeks. September 30, 2019. https://www.geeksforgeeks.org/how-to-convert-an-array-to-string-in-java/. 
    4.“Java.lang.string.replace() Method in Java.” 2018. GeeksforGeeks. December 4, 2018. https://www.geeksforgeeks.org/java-lang-string-replace-method-java/. 
    5.Savitch, Walter, and Kenrick Mock. 2010. Absolute Java. Boston: Pearson Education. 
    6. “Java Integer Compare() Method.” 2018. GeeksforGeeks. December 5, 2018. https://www.geeksforgeeks.org/java-integer-compare-method/#:~:text=Syntax%20%3A,To%20show%20working%20of%20java. 
    7.“Different Ways for Integer to String Conversions In Java.” 2020. GeeksforGeeks. December 11, 2020. https://www.geeksforgeeks.org/different-ways-for-integer-to-string-conversions-in-java/. 
    8.“Difference between == and .Equals() Method in Java.” 2020. GeeksforGeeks. March 30, 2020. https://www.geeksforgeeks.org/difference-equals-method-java/. 
    9.Baeldung. 2021. “Check If a String Is Numeric in Java.” Baeldung. January 30, 2021. https://www.baeldung.com/java-check-string-number. 
    10.“Java Convert String to Int - Javatpoint.” n.d. Www.javatpoint.com. Accessed February 28, 2021. https://www.javatpoint.com/java-string-to-int#:~:text=We%20can%20convert%20String%20to,returns%20instance%20of%20Integer%20class.  
    11.  “Java Constructor Style: Check Parameters Aren't Null.” Stack Overflow. May 1, 1959. https://stackoverflow.com/questions/2997768/java-constructor-style-check-parameters-arent-null/34855129.  
    */
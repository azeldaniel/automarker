/*
   ID: 816006488 
   */
import java.util.Scanner;
public class VirtualRunner
{
    public static void main(String[] args){
    
    VirtualMeetingSystem event = new VirtualMeetingSystem();
    
    event.createVirtualRoom("Seminar");
    event.loadParticipantData("participant.dat");
    
    int choice,val;
    String code,iD;
    System.out.println("Select Option Rooms or 0 to end: rooms are numbered 0-4\n"+
                        "1. Allocate Participants\n"+
                        "2. Add Participant to Breakoutroom\n"+
                        "3. Open BreakoutRoom\n"+ 
                        "4. Close BreakoutRoom\n"+
                        "5. Find Participant\n"+
                        "6. List all BreakoutRooms\n"+
                        "7. List all participants in BreakoutRoom\n"+
                        "8. Close System\n");
    
    Scanner scan = new Scanner(System.in);
    Scanner scan2 = new Scanner(System.in);
    Scanner scan3= new Scanner(System.in);
    choice = scan.nextInt();
    //loop testing area: 
     while(choice != 0){
         switch(choice){
            
             case 1:
                System.out.println("Select Option C5 or RR:\n ");
                code=scan2.nextLine();
                event.allocateParticipants(code);
                break;
             case 2:
                System.out.println("Enter Participant ID: ");
                iD=scan2.nextLine();
                System.out.println("Enter RoomNumber: ");
                val = scan3.nextInt();
                event.addParticipant (iD,val);
                break;
             case 3:
                System.out.println("Enter room to open (#0-4): ");
                val = scan3.nextInt();
                event.openBreakoutRoom(val);
                break;
             case 4:
                System.out.println("Enter room to close (#0-4): ");
                val = scan3.nextInt();
                event.closeBreakoutRoom(val);
                break;
             case 5:
                System.out.println("Enter Participant ID to find: ");
                iD=scan2.nextLine();
                System.out.print(event.findParticipantBreakoutRoom(iD)+"\n");
                break;
             case 6:
                System.out.println(event.listAllBreakoutRooms());
                break;
             case 7:
                System.out.println(event.listParticipantsInAllBreakoutRooms());
                break;
             case 8:
                System.exit(0);
                break;
             default:
                break;
                
            }
          System.out.println("Select Option Rooms or 0 to end: rooms are numbered 0-4\n"+
                        "1. Allocate Participants\n"+
                        "2. Add Participant to Breakoutroom\n"+
                        "3. Open BreakoutRoom\n"+ 
                        "4. Close BreakoutRoom\n"+
                        "5. Find Participant\n"+
                        "6. List all BreakoutRooms\n"+
                        "7. List all participants in BreakoutRoom\n"+
                        "8. Close System\n");
          choice = scan.nextInt();
        }  
     
    //Participants Check
    //Participant a = new Participant("00000000");
    //System.out.println(a.toString());
    //a.toString();
    //if(a.verifyID("0000000")==true){
     //  System.out.println("Valid ID");
    //}
    //else
    //{
     //   System.out.println("Invalid ID");
    //}
    //System.out.println(a.toString());
    //BreakoutRoom Check
    //BreakoutRoom a = new BreakoutRoom("Seminar");
    //a.openBreakoutRoom();
    
    //a.addParticipant("12345678");
    //a.addParticipant("87654321");
    //a.addParticipant("12345678");
    //a.addParticipant("00000000");
    //if(a.addParticipant("00000000")==true){
     //   System.out.println("Yay");
    //}
    //else
    //{
     //  System.out.println("NO");
    //}
    //System.out.println(a. findParticipant("00000000"));
    //System.out.println(a.listParticipants());
    //System.out.println(a.getOpen());
    //Virtual Room Check
    //VirtualRoom a = new VirtualRoom("Seminar");
    //a.createBreakoutRooms();
    //a.openBreakoutRoom (0);
    //a.createBreakoutRooms();
    //a.openBreakoutRoom (1);
    //a.addParticipantToBreakoutRoom("00000001", 1);
    //a.addParticipantToBreakoutRoom("00000002", 1);
    //a.addParticipantToBreakoutRoom("00000001", 0);
   // a.addParticipantToBreakoutRoom("00000003", 3);
    //a.addParticipantToBreakoutRoom("00000004", 0);
    //b.addParticipantToBreakoutRoom("00000005", 1);
    //b.addParticipantToBreakoutRoom("00000006", 1);
    //a.addParticipantToBreakoutRoom("00000003", 1);
    //System.out.println(a.findParticipantBreakoutRoom("00000006"));
    //System.out.println(a.listParticipantsInBreakoutRoom(1));
    //System.out.println(a.listParticipantsInBreakoutRoom(3));
    //System.out.println(a.getNumberOfBreakoutRooms());
    //Virtual Meeting System test
    
    //VirtualMeetingSystem a = new VirtualMeetingSystem();
    //a.loadParticipantData("participant.dat");
    //a.createVirtualRoom("Seminar");
    //a.openBreakoutRoom(0);
    //a.addParticipant ("12345678",2);
    //a.allocateParticipants("RR");
    //System.out.println(a.listAllBreakoutRooms());
    //System.out.println(a.listParticipants(2));
    //a.addParticipant ("12345678",2);
    //System.out.println(a.listParticipants(2));
    //a.closeBreakoutRoom(2);
    //System.out.println(a.listAllBreakoutRooms());
    //a.openBreakoutRoom(2);
    //System.out.println(a.listAllBreakoutRooms());
  }
} 

/*
    References:
    1.Java Read Files. Accessed February 7, 2021. https://www.w3schools.com/java/java_files_read.asp. 
    2.“Different Ways of Reading a Text File in Java.” 2018. GeeksforGeeks. September 6, 2018. https://www.geeksforgeeks.org/different-ways-reading-text-file-java/. 
    3.“How to Convert an Array to String in Java?” 2019. GeeksforGeeks. September 30, 2019. https://www.geeksforgeeks.org/how-to-convert-an-array-to-string-in-java/. 
    4.“Java.lang.string.replace() Method in Java.” 2018. GeeksforGeeks. December 4, 2018. https://www.geeksforgeeks.org/java-lang-string-replace-method-java/. 
    5.Savitch, Walter, and Kenrick Mock. 2010. Absolute Java. Boston: Pearson Education. 
    6. “Java Integer Compare() Method.” 2018. GeeksforGeeks. December 5, 2018. https://www.geeksforgeeks.org/java-integer-compare-method/#:~:text=Syntax%20%3A,To%20show%20working%20of%20java. 
    7.“Different Ways for Integer to String Conversions In Java.” 2020. GeeksforGeeks. December 11, 2020. https://www.geeksforgeeks.org/different-ways-for-integer-to-string-conversions-in-java/. 
    8.“Difference between == and .Equals() Method in Java.” 2020. GeeksforGeeks. March 30, 2020. https://www.geeksforgeeks.org/difference-equals-method-java/. 
    9.Baeldung. 2021. “Check If a String Is Numeric in Java.” Baeldung. January 30, 2021. https://www.baeldung.com/java-check-string-number. 
    10.“Java Convert String to Int - Javatpoint.” n.d. Www.javatpoint.com. Accessed February 28, 2021. https://www.javatpoint.com/java-string-to-int#:~:text=We%20can%20convert%20String%20to,returns%20instance%20of%20Integer%20class.  
    11.  “Java Constructor Style: Check Parameters Aren't Null.” Stack Overflow. May 1, 1959. https://stackoverflow.com/questions/2997768/java-constructor-style-check-parameters-arent-null/34855129.  
    */
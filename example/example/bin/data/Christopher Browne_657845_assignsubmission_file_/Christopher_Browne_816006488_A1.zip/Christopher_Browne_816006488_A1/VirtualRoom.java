/*
   ID: 816006488  
   */
import java.io.*; 
import java.util.*; 
import java.lang.*; 

public class VirtualRoom
{
    private String name;
    private final int breakoutRoomLimit;
    private BreakoutRoom[] breakoutRooms;
    private static int count = 0;
    
    public VirtualRoom(String name){
        this.name=name;
        breakoutRoomLimit = 5;
        breakoutRooms = new BreakoutRoom[breakoutRoomLimit] ;
    }
    
    public VirtualRoom(String name, int limit){
        this.name=name;
        this.breakoutRoomLimit =limit;
        breakoutRooms = new BreakoutRoom[breakoutRoomLimit];
    }
    
    public int getNumberOfBreakoutRooms(){
        System.out.print("There are "+count+" rooms.");
        if(count==breakoutRoomLimit)
        {
            System.out.println("Maximum Number of Rooms Reached");
        }
        return count;
    }
    
    public void createBreakoutRooms(){
       
       if(count==breakoutRoomLimit)
       {
           System.out.println("Cannot open more rooms");
       }
       BreakoutRoom room = new BreakoutRoom(name);
       breakoutRooms[count]=room;
       count++;
    }
    
    public BreakoutRoom findBreakoutRoom(int roomNumber){
        int check = 0;        
        while(check < breakoutRoomLimit){
            
            if(check == roomNumber){
                return breakoutRooms[check];
            }
            check++;
        }
        return null;
    }
    
    public boolean closeBreakoutRoom (int roomNumber){
        if(roomNumber>= breakoutRoomLimit)
         {
           System.out.println("Room number: "+roomNumber+" does not exist.\n");
           return false;
         }
        if(breakoutRooms[roomNumber]==null){
            System.out.println("Room number: "+roomNumber+" does not exist.\n");
            return false;
            
        }
        breakoutRooms[roomNumber].closeBreakoutRoom();
        return true;
    }
    
    public boolean openBreakoutRoom (int roomNumber){
        if(roomNumber>= breakoutRoomLimit)
         {
           System.out.println("Room number: "+roomNumber+" does not exist\n");
           return false;
         }
        if(breakoutRooms[roomNumber] == null)
        {
            int temp = count;
            count=roomNumber;
            createBreakoutRooms();
            count=temp;            
            breakoutRooms[roomNumber].openBreakoutRoom();
            count++;
            return true;
        }
        else
        {
            breakoutRooms[roomNumber].openBreakoutRoom();
        }        
        return false;
    }
    
    public String listBreakoutRooms(){
        int check=0;
        String listed[]=new String[breakoutRoomLimit];
        while(check < breakoutRoomLimit){
          if(breakoutRooms[check]!=null){
              
            listed[check] = breakoutRooms[check].toString()+"\n";
                
            }
            else{
               listed[check] =""; 
            }
          
          check++;
        }
        return(Arrays.toString(listed).replace("[","").replace("]","").replace(",",""));
    }
    
    public String listParticipantsInBreakoutRoom(int roomNumber){
        if(roomNumber >= breakoutRoomLimit)
         {
           return ("Room number: "+roomNumber+" does not exist.\n");
         }
        
        if(breakoutRooms[roomNumber] != null)
        {
            return breakoutRooms[roomNumber].listParticipants();
        }
        return "";
        
    }
    
    public boolean addParticipantToBreakoutRoom(String participantID, int roomNumber){
        if(findParticipantBreakoutRoom (participantID) != null){
            System.out.println("Duplicate present, cannot add");
            return false;
        }
        if(roomNumber>= breakoutRoomLimit)
         {
           System.out.println("Room number: "+roomNumber+" does not exist.\n");
           return false;
         }
        if(breakoutRooms[roomNumber] == null){
            System.out.println("Room number: "+roomNumber+" is closed.\n");
            return false;
        }
        if(breakoutRooms[roomNumber].addParticipant(participantID)==true)
        {
            return true;
        }
        return false;
    }
    
    public String findParticipantBreakoutRoom (String participantID){
        int check=0;
        
        while(check < breakoutRoomLimit){
            
           if(breakoutRooms[check]!=null){
               
               if(breakoutRooms[check].findParticipant(participantID) != null){
                  
                   return("ID: "+participantID+" In "+breakoutRooms[check].getBreakoutRoomID());
                   
                }
             
              
            }
           check++; 
            
        }
        return null;
    }
}
/*
    /*
    References:
    1.Java Read Files. Accessed February 7, 2021. https://www.w3schools.com/java/java_files_read.asp. 
    2.“Different Ways of Reading a Text File in Java.” 2018. GeeksforGeeks. September 6, 2018. https://www.geeksforgeeks.org/different-ways-reading-text-file-java/. 
    3.“How to Convert an Array to String in Java?” 2019. GeeksforGeeks. September 30, 2019. https://www.geeksforgeeks.org/how-to-convert-an-array-to-string-in-java/. 
    4.“Java.lang.string.replace() Method in Java.” 2018. GeeksforGeeks. December 4, 2018. https://www.geeksforgeeks.org/java-lang-string-replace-method-java/. 
    5.Savitch, Walter, and Kenrick Mock. 2010. Absolute Java. Boston: Pearson Education. 
    6. “Java Integer Compare() Method.” 2018. GeeksforGeeks. December 5, 2018. https://www.geeksforgeeks.org/java-integer-compare-method/#:~:text=Syntax%20%3A,To%20show%20working%20of%20java. 
    7.“Different Ways for Integer to String Conversions In Java.” 2020. GeeksforGeeks. December 11, 2020. https://www.geeksforgeeks.org/different-ways-for-integer-to-string-conversions-in-java/. 
    8.“Difference between == and .Equals() Method in Java.” 2020. GeeksforGeeks. March 30, 2020. https://www.geeksforgeeks.org/difference-equals-method-java/. 
    9.Baeldung. 2021. “Check If a String Is Numeric in Java.” Baeldung. January 30, 2021. https://www.baeldung.com/java-check-string-number. 
    10.“Java Convert String to Int - Javatpoint.” n.d. Www.javatpoint.com. Accessed February 28, 2021. https://www.javatpoint.com/java-string-to-int#:~:text=We%20can%20convert%20String%20to,returns%20instance%20of%20Integer%20class.  
    11.  “Java Constructor Style: Check Parameters Aren't Null.” Stack Overflow. May 1, 1959. https://stackoverflow.com/questions/2997768/java-constructor-style-check-parameters-arent-null/34855129.  
    */
/*
   ID: 816006488 
   */
import java.io.*; 
import java.util.*; 
public class BreakoutRoom
{
    private String breakoutRoomID;
    private static int breakoutRoomNumberCounter=1;
    private final int breakoutRoomSize;
    private Participant[] participants;
    private int numberOfParticipants;
    private boolean open;
    private int roomID;
    
    public BreakoutRoom(String name)
    {
        roomID=breakoutRoomNumberCounter;
        numberOfParticipants=0;
        open = false;
        breakoutRoomSize=10;
        this.breakoutRoomID=name+roomID;
        participants=new Participant[10];
        if(breakoutRoomID == null){
           throw new IllegalArgumentException("Invalid ID");
        }
    }
    
    public boolean addParticipant(String participantID)
    {
       Participant temp =  new Participant(participantID);
       
       if(numberOfParticipants==breakoutRoomSize || temp.verifyID(participantID)==false||open==false)
       {
           return false;
       }
       else
       {
           int check =0;
           while (check < numberOfParticipants)
           {
               if(participants[check].getParticipantID().equals(participantID))
               {
                   check++;
                   return false;
               }
               else
               {
                   check++;
               }
           }
           
           participants[numberOfParticipants] = temp;
           numberOfParticipants++;
           return true;
        }
    }
    
    public Participant findParticipant(String participantID){
          int check =0;
          String tempe;
         
          while (check < numberOfParticipants)
          {
              
              if(participants[check]==null)  
              {
               return null;
              }
              else
              {
                  tempe = participants[check].getParticipantID();
                 
                if(tempe.equals(participantID)==true)
                {
                   
                    Participant one = new Participant(tempe);
                    return one;
                    
                }
              }
              check++;
          }
          return null;
    }
    
    public String listParticipants(){
      int check =0;
      String partici[]= new String[numberOfParticipants];
      while (check < numberOfParticipants){
         if(check==0)
         {
            partici[check]=getBreakoutRoomID()+"\n "+participants[check].getParticipantID()+"\n";
         }
         else
         {
            partici[check]=participants[check].getParticipantID()+"\n";
         }         
         check++;
      } 
      return (Arrays.toString(partici).replace("[","").replace("]","")); 
    }
    
    public String toString(){
        String status;
        if(getOpen() == true)
        {
            status = "OPEN";
        }
        else
        {
            status = "CLOSE";
        }
        
        return(getBreakoutRoomID()+" "+status+" "+getNumberOfParticipants());
    
    }
    
    public void closeBreakoutRoom(){
    
        int check=0;
        
        while(check < numberOfParticipants ){
           participants[check]=null; 
           check++;
        }
        numberOfParticipants=0;
        open=false;
    }
    
    public void openBreakoutRoom(){
      open=true;
      breakoutRoomNumberCounter++;  
   }
    
   public int getNumberOfParticipants(){
       return numberOfParticipants; 
    }
    
    public String getBreakoutRoomID(){
        return breakoutRoomID;
    }
    
    public boolean getOpen(){
        return open;
    }
    
}
/*
    References:
    1.Java Read Files. Accessed February 7, 2021. https://www.w3schools.com/java/java_files_read.asp. 
    2.“Different Ways of Reading a Text File in Java.” 2018. GeeksforGeeks. September 6, 2018. https://www.geeksforgeeks.org/different-ways-reading-text-file-java/. 
    3.“How to Convert an Array to String in Java?” 2019. GeeksforGeeks. September 30, 2019. https://www.geeksforgeeks.org/how-to-convert-an-array-to-string-in-java/. 
    4.“Java.lang.string.replace() Method in Java.” 2018. GeeksforGeeks. December 4, 2018. https://www.geeksforgeeks.org/java-lang-string-replace-method-java/. 
    5.Savitch, Walter, and Kenrick Mock. 2010. Absolute Java. Boston: Pearson Education. 
    6. “Java Integer Compare() Method.” 2018. GeeksforGeeks. December 5, 2018. https://www.geeksforgeeks.org/java-integer-compare-method/#:~:text=Syntax%20%3A,To%20show%20working%20of%20java. 
    7.“Different Ways for Integer to String Conversions In Java.” 2020. GeeksforGeeks. December 11, 2020. https://www.geeksforgeeks.org/different-ways-for-integer-to-string-conversions-in-java/. 
    8.“Difference between == and .Equals() Method in Java.” 2020. GeeksforGeeks. March 30, 2020. https://www.geeksforgeeks.org/difference-equals-method-java/. 
    9.Baeldung. 2021. “Check If a String Is Numeric in Java.” Baeldung. January 30, 2021. https://www.baeldung.com/java-check-string-number. 
    10.“Java Convert String to Int - Javatpoint.” n.d. Www.javatpoint.com. Accessed February 28, 2021. https://www.javatpoint.com/java-string-to-int#:~:text=We%20can%20convert%20String%20to,returns%20instance%20of%20Integer%20class.  
    11.  “Java Constructor Style: Check Parameters Aren't Null.” Stack Overflow. May 1, 1959. https://stackoverflow.com/questions/2997768/java-constructor-style-check-parameters-arent-null/34855129.  
    */
//816004029


public class VirtualRunner
{
    
    public static void main(String[] args)
    {
         
        VirtualMeetingSystem.createVirtualRoom("Workshop");
        
        //VirtualRoom workshop = new createVirtualRoom("Workshop");
    }

    
}

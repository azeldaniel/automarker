// Student ID: 816022470
/**
 * Write a description of class VirtualRunner here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class VirtualRunner{
    
    public static void main(String[] args){ 
        VirtualMeetingSystem virtualMS = new VirtualMeetingSystem();
        virtualMS.loadParticipantData ("participant.dat");
        
        /* 
        BreakoutRoom breakOR = new BreakoutRoom("Seminar");
        breakOR.addParticipant ("38829384");
        String roomList = breakOR.listParticipants();
        System.out.print(roomList);
        */
       
    }   
    
   
    
}



/**
 * 816019400
 */
public class VirtualRunner
{
    public static void main(String[] args){
        VirtualMeetingSystem vs = new VirtualMeetingSystem();
        vs.createVirtualRoom("Workshop");
        vs.loadParticipantData("participant.dat");
        vs.allocateParticipants("C5");
        System.out.println(vs.listParticipantsInAllBreakoutRooms());
        
    }
}

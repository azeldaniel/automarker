//ID:816004672
import java.io.File;
import java.util.Scanner;

/**
 * Write a description of class VirtualMeetingSystem here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VirtualMeetingSystem
{
    // instance variables - replace the example below with your own
    private VirtualRoom virtualRoom;
    

    /**
     * Constructor for objects of class VirtualMeetingSystem
     */
    public VirtualMeetingSystem()
    {
        // initialise instance variables
        
        
    }
    
    public void loadParticipantData(String filename)
    {
           
        File f = new File("participant.dat");
        
    }
    
    public void createVirtualRoom(String name)
    {
        
    }

}

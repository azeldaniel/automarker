//816016640

public class VirtualRunner
{
    
    public static void main(String[] args){
        VirtualMeetingSystem VirtualMeet = new VirtualMeetingSystem();
      
        VirtualMeet.loadParticipantData("participant.dat");

        VirtualMeet.createVirtualRoom("Conferance");
        
       
        VirtualMeet.allocateParticipants("C3");
        
       
    }
}
